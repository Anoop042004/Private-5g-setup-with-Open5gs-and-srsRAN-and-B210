# We have used Oppo Reno 5g mobile phone for connections

### 1. Insert the sim in the mobile phone

### 2. Check if phone detect the sim

### 3. Manually add APN
```
Go to settings
Go to network settings.
Go to add access network name

Create new APN
    - name srsapn
    - apn srsapn
    - roaming protocal IPv4

  Create APN.
```

## Check if srsGNB and Open5gs are running correctly.

## Put the Phone once in Aeroplane ✈️ Mode and check connectivity.

====================================================================================================================================================================

## If still no connectivity use third party applications to put phone in NR Mode.

We used `Netmonster` can be downloaded from Playstore.



![image](https://github.com/user-attachments/assets/c330090c-b70e-4921-b32a-2045a6bd5297)


```
In Netmonster

select `Phone Info` from three dots from bottom corner.
In the Phone Info:
  - select Set Preferred Network type `NR only`
  - ON Aeroplane mode and try to connect the Network.
```

![WhatsApp Image 2025-04-12 at 23 25 17_3ca725a6](https://github.com/user-attachments/assets/6bc4a448-ca70-4609-a7fd-a108ff1ba589)

![WhatsApp Image 2025-04-12 at 23 25 17_faed914a](https://github.com/user-attachments/assets/3cf76336-2d43-4a20-864b-6641dc26ac9d)

# Now we are getting 5g Internet

![image](https://github.com/user-attachments/assets/a3a51ac7-a796-41d6-a865-8e8e1cf17c74)



