# In the Browser where Open5gs is Installed.

## Open Browser and go to http://localhost:9999

## Credentials:

```
Username: admin
Password: 1423
```

# Click on add subscriber

### 1. Add IMSI Number
```
In the field of IMSI  add 001010000000001

15 digit number.
```

### 2. Add Subscriber key and Operator Key.

```
Add the following for simplicity (We use the same to configure SIM)
Subscriber Key: 6874736969202073796d4b2079650a73
Operator Key: 504f20634f6320504f50206363500a4f 

```

### 3. In the apn/dnn section

```
Now we are going to use `srsapn` so add same. and IPv4 protocol.
```

# Now create the user. 
