# Now we can check the connectivity speed   using any online applications.


![Screenshot 2025-04-12 232625](https://github.com/user-attachments/assets/e3d80749-014a-4ba7-955f-6d4a0a7596fc)


# Use Ping to measure Latency

```
ping google.com

This also ensures working of DNS
```
